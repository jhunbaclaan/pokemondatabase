import streamlit as st
import pypokedex as pokedex
import pandas as pd
from pokemon_filters import get_gen, filter_by_gen, filter_by_bst, filter_by_type, get_all


def query_pokemon():

    # sets session windows
    if 'gen_filter' not in st.session_state:
        st.session_state['gen_filter'] = False
    if 'type_filter' not in st.session_state:
        st.session_state['type_filter'] = False
    if 'bst_filter' not in st.session_state:
        st.session_state['bst_filter'] = False
    if 'all_filter' not in st.session_state:
        st.session_state['all_filter'] = False
    
    
    # sets session vars
    if 'poke_list' not in st.session_state:
        st.session_state.poke_list = []
        
        
    
    # creates a dataframe and lists to add to the dataframe later
    pokemon_df = pd.DataFrame(columns=['Pokemon_ID', 'Pokemon_Name', 'Pokemon_Type1', 'Pokemon_Type2', 'Pokemon_Gen', 'Pokemon_BST'])
    dexnum_list = []
    name_list = []
    bst_list = []
    type1_list = []
    type2_list = []
    gen_list = []
    poke_list = st.session_state.poke_list
    
    
    st.title('Select Pokemon to make available for the draft')
    
    st.write('Filter by:')
    
    cola, colb, colc, cold = st.columns([1, 1, 1, 1])
    
    with cola:
        bygen = st.button('Generation', key='bygen')
        if bygen:
            
            st.session_state['gen_filter'] = True
            st.rerun()
            
    with colb:
        bytypes = st.button('Types', key='bytypes')
        if bytypes:
            
            st.session_state['type_filter'] = True
            st.rerun()
            
    with colc:
        bybst = st.button('Base Stats', key='bybst')
        if bybst:
            st.session_state['bst_filter'] = True
            st.rerun()
            
    with cold:
        
        byall = st.button('All Pokemon', key='byall')
        if byall:
            st.session_state['all_filter'] = True
            st.rerun()
            
    
    if st.session_state['gen_filter']:
    
        poke_list = st.session_state.poke_list
        
        st.write('Select generations of pokemon you want to choose from')
        sel_gen_list = st.multiselect('', range(1, 10), key='select_gen')
        
        confirm_gen = st.button('Confirm', key='confirm_gen')
    
        if confirm_gen:
            poke_list = filter_by_gen(sel_gen_list, poke_list)
            st.session_state.poke_list = poke_list
            st.session_state['gen_filter'] = False
            st.rerun()
    
    elif st.session_state['type_filter']:
    
        poke_list = st.session_state.poke_list
    
        
        # pokemon types to choose from for a drop down
        type_list = ['normal', 'fighting', 'rock', 'ground', 'grass', 'fire', 'water', 'ice', 'steel', 'electric', 'dark', 'ghost', 'flying', 'bug', 'poison', 'fairy', 'dragon', 'psychic']
    
        
        sel_type_list = st.multiselect('', type_list, key='select_type')
    
        confirm_type = st.button('Confirm', key='confirm_type')
    
        if confirm_type:
            
            poke_list = filter_by_type(sel_type_list, poke_list)
            st.session_state.poke_list = poke_list
            st.session_state['type_filter'] = False
            st.rerun()
    
    elif st.session_state['bst_filter']:
    
        poke_list = st.session_state.poke_list
        
        st.subheader('Enter the Base Stat Total range you want to filter by')
        col1, col2 = st.columns([1, 1])
        with col1:
            
            low_bst = st.text_input('Low BST', key='low_bst')
            try:
                low_bst = int(low_bst)
            except Exception as e:
                st.write('Error: Input a number')
                st.stop()
        with col2:
            
            high_bst = st.text_input('High BST', key='high_bst')
            # verifies input was an int
            try:
                high_bst = int(high_bst)
            except Exception as e:
                st.write('Error: Input a number')
                st.stop()
    
    
        confirm_bst = st.button('Confirm', key='confirm_bst')
    
        if confirm_bst:
            poke_list = filter_by_bst(low_bst, high_bst, poke_list)
            st.session_state.poke_list = poke_list
            st.session_state['bst_filter'] = False
            st.rerun()
    
    elif st.session_state['all_filter']:
    
        st.session_state.poke_list = get_all()
        st.session_state['all_filter'] = False
        st.rerun()
    
    
    # creates column data to insert
    for pok in poke_list:
    
        
        gen_list.append(get_gen(pok.dex))
        dexnum_list.append(pok.dex)
        name_list.append(pok.name)
        type1_list.append(pok.types[0])
        try:
            type2_list.append(pok.types[1])
        except Exception as e:
            type2_list.append(None)
        bst_list.append(sum(pok.base_stats))
    
    # fills the columns with pokemon selected
    pokemon_df.Pokemon_ID = dexnum_list
    pokemon_df.Pokemon_Name = name_list
    pokemon_df.Pokemon_Type1 = type1_list
    pokemon_df.Pokemon_Type2 = type2_list
    pokemon_df.Pokemon_Gen = gen_list    
    pokemon_df.Pokemon_BST = bst_list
    pokemon_df['Pokemon_Avail'] = True 
    
    # removes possible duplicate primary keys
    pokemon_df = pokemon_df.drop_duplicates(subset='Pokemon_ID', keep='first')
    
    # shows the data
    st.caption(f'{len(pokemon_df)} pokemon are selected')
    st.dataframe(pokemon_df, height=250)
    
    if not pokemon_df.empty:
        confirm_selection = st.button('Use Selected', key='confirm_selection')