import pandas as pd
import pymysql
import streamlit as st

def insert_pokemon(ids, league_id, names, type1s, type2s, gens, stats, avails):

    data = list(zip(ids, league_id, names, type1s, type2s, gens, stats, avails))
    sql = '''INSERT INTO POKEMON (Pokemon_ID, LeagueID, Pokemon_Name, Pokemon_Type1, Pokemon_Type2, Pokemon_Gen, Pokemon_BST, Pokemon_Avail)
    VALUES (%s, %s, %s, %s, %s, %s, %s)'''

# iterates through users to get new id
def getUserID(cursor):
    
    cursor.execute("""SELECT UserID FROM Users ORDER BY UserID DESC LIMIT 1;""")
    user_id = cursor.fetchall()[0][0] + 1

    return user_id 

# method to input new users
def insertUser(cursor, first_name, last_name, email):
    
    user_id = getUserID(cursor)
    
    query = f"""INSERT INTO Users (UserID, LeagueID, HostFlag, UserFirstName, UserLastName, UserEmail) 
    VALUES({user_id}, {158}, {False}, "{first_name}", "{last_name}", "{email}");"""
    return query



    