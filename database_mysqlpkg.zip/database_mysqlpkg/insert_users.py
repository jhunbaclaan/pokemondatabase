# code for making your user:
import streamlit as st
import pymysql
import pandas as pd
from runs_sql import getUserID, insertUser

def create_new_user(db, cursor):
    
    user_df = pd.DataFrame(columns=['First_Name', 'Last_Name', 'Email'])
    st.title('Create User Profile')
    first_name = st.text_input('Input first name', key='fn')
    last_name = st.text_input('Input last name', key='ln')
    email = st.text_input('Input email', key='email')
    # stops the query if values have not been inputted
    if first_name is '' or last_name is '' or email is '':
        st.stop()
    else:
        try:
            query = insertUser(cursor, first_name, last_name, email)
            cursor.execute(query)
            db.commit()  # Commit the transaction

            st.write('Your user profile has been created!')
    	  
        except Exception as e:
            st.write(insertUser(cursor, first_name, last_name, email))
            st.write(f'An error occurred: {e}')
    db.close()