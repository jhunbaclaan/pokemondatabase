import streamlit as st
import pypokedex as pokedex
import pandas as pd

# function to get the pokemon's generation
def get_gen(dexnum):

    counter=1

    gen1 = [ i for i in range(1, 152) ]
    gen2 = [ i for i in range(152, 252) ]
    gen3 = [ i for i in range(252, 387) ]
    gen4 = [ i for i in range(387, 494) ]  
    gen5 = [ i for i in range(494, 650) ] 
    gen6 = [ i for i in range(650, 722) ] 
    gen7 = [ i for i in range(722, 810) ]
    gen8 = [ i for i in range(810, 906) ]
    gen9 = [ i for i in range(906, 1026) ]
    gen4 += ( i for i in range(10001, 10013) )
    gen5 += ( i for i in range(10016, 10025) )
    gen6 += ( i for i in range(10025, 10182, 156) )
    gen7 += ( i for i in range(10091, 10093))
    gen7 += ( i for i in range(10100, 10158))
    gen8 += ( i for i in range(10162, 10195) if i != 10181)
    gen8 += (i for i in range(10229, 10250))
    gen9 += ( i for i in range(10250, 10277))

    gens = [gen1, gen2, gen3, gen4, gen5, gen6, gen7, gen8, gen9]

    for gen in gens:
    
        if dexnum in gen:
            return counter
        else:
            counter+=1

# function to filter pokemon by generatio
def filter_by_gen(gen_num, pokelist):

    selected_gen = []
    pokelist2 = []
    
    gen1 = [ i for i in range(1, 152) ]
    gen2 = [ i for i in range(152, 252) ]
    gen3 = [ i for i in range(252, 387) ]
    gen4 = [ i for i in range(387, 494) ]  
    gen5 = [ i for i in range(494, 650) ] 
    gen6 = [ i for i in range(650, 722) ] 
    gen7 = [ i for i in range(722, 810) ]
    gen8 = [ i for i in range(810, 906) ]
    gen9 = [ i for i in range(906, 1026) ]
    gen4 += ( i for i in range(10001, 10013) )
    gen5 += ( i for i in range(10016, 10025) )
    gen6 += ( i for i in range(10025, 10182, 156) )
    gen7 += ( i for i in range(10091, 10093))
    gen7 += ( i for i in range(10100, 10158))
    gen8 += ( i for i in range(10162, 10195) if i != 10181)
    gen8 += (i for i in range(10229, 10250))
    gen9 += ( i for i in range(10250, 10277))

    gens = [gen1, gen2, gen3, gen4, gen5, gen6, gen7, gen8, gen9]

    for num in gen_num:
        
        selected_gen += gens[num-1]

    if pokelist == []:
        for num in selected_gen:
    
            pokelist.append(pokedex.get(dex=num))
    
        return pokelist

    # using existing list if present
    else:
        
        for num in selected_gen:

            pokelist2.append(pokedex.get(dex=num))

        pokelist = [ poke for poke in pokelist2 if poke in pokelist ]

        return pokelist
            
    
        

# option to filter pokemon by their typing
def filter_by_type(type_query, pokelist):

    pokelist2 = []


    
    for pokemon_type in type_query:
        st.write(pokemon_type)
        for num in range(1, 1026):

            if pokemon_type in pokedex.get(dex=num).types:

                pokelist2.append(pokedex.get(dex=num))

        for num in range(10001, 10277):

            if pokemon_type in pokedex.get(dex=num).types:

                pokelist2.append(pokedex.get(dex=num))

    if pokelist == []:

        return pokelist2
        
    else:

        pokelist = [poke for poke in pokelist2 if poke in pokelist]

        return pokelist

# function to filter pokemon by a base stat range
def filter_by_bst(low_bst, high_bst, pokelist):

    pokelist2 = []


    for num in range(1, 1026):

        if low_bst <= sum(pokedex.get(dex=num).base_stats) <= high_bst :
                
            pokelist2.append(pokedex.get(dex=num))

    for num in range(10001, 10277):
    
        if low_bst <= sum(pokedex.get(dex=num).base_stats) <= high_bst:
    
            pokelist2.append(pokedex.get(dex=num))

    if pokelist == []:
        
        return pokelist2

    else:
        
        pokelist = [ poke for poke in pokelist2 if poke in pokelist ]
        
        return pokelist

def get_all():

    poke_list = []
    
    for num in range(1, 1026):
                
            poke_list.append(pokedex.get(dex=num))
    
    for num in range(10001, 10277):

        poke_list.append(pokedex.get(dex=num))

    return poke_list