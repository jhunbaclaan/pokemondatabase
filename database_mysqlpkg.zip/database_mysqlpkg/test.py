import streamlit as st
import pypokedex as pokedex
import pandas as pd
import requests
import csv
import os

# gets match history
def get_sets(user, set_df, match_df, user_df):

    # merges set and matches to one table based on match id
    temp_set_df = pd.merge(set_df, match_df, on='Match_ID', how='inner')

    # drops second player
    temp_set_df1 = temp_set_df.drop(columns=['Player2_ID'])

    # renames player1 to user ID
    temp_set_df1 = temp_set_df1.rename(columns={'Player1_ID' : 'UserID'})

    # makes a second df to get match result
    temp_set_df2 = temp_set_df.drop(columns=['Player1_ID'])

    # same as df1
    temp_set_df2 = temp_set_df2.rename(columns={'Player2_ID' : 'UserID'})

    # function to switch match results to relfect player 2's results
    temp_set_df2['Match_Result'] = temp_set_df1['Match_Result'].apply(lambda res: 'W' if res == 'L' else 'L')
    
    #st.dataframe(temp_set_df2)

    # merges the user table to the set datafrane we made on userID
    new_set_df1 = pd.merge(temp_set_df1, user_df, on='UserID', how='inner')
    new_set_df2 = pd.merge(temp_set_df2, user_df, on='UserID', how='inner')

    # creates a new df that shows who each match was against and who won
    vs_user = new_set_df2[['Set_ID', 'UserFirstName']]

    # filters out unnecessaru columns
    new_set_df1 = new_set_df1[['Set_ID', 'Match_number', 'Match_Result', 'Match_Date', 'UserFirstName']]

    # queries for the user selected
    user_set= new_set_df1.query(f'UserFirstName == "{user}"')

    # merges for that user
    user_set = pd.merge(user_set, vs_user, on='Set_ID', how='inner')

    # gets data wgere it is not other user's
    user_set = user_set.query(f'UserFirstName_y != "{user}"')

    # drops duplicates made from the merge
    user_set = (user_set.drop_duplicates(subset=['Match_number'], keep='first')).reset_index(drop=True)

    # drops the user name column as its the same for every row since its viewed by user
    user_set = user_set.drop(columns=['UserFirstName_x'])

    # changes user2 to opponent for clarity
    user_set = user_set.rename(columns={'UserFirstName_y' : 'Opponent'})
    
    return user_set

def get_box(user, user_df, pokemon_df, pokemonbox_df):

    # creates a dataframe that filters out unnecessary columns
    user_df_to_join = user_df[['UserID', 'UserFirstName']]
    pokemon_df_to_join = pokemon_df[['Pokemon_ID', 'Pokemon_Name']]

    # join user to pokemonbox on User_ID
    temp_pokemonbox_df = pd.merge(pokemonbox_df, user_df_to_join, on='UserID', how='inner')

    # join pokemon to pokemon box on Pokemon_ID
    new_pokemonbox_df = pd.merge(temp_pokemonbox_df, pokemon_df_to_join, on='Pokemon_ID', how='inner')

    
    # queries for pokemon box owned by the selected users
    logan_pokemonbox = new_pokemonbox_df.query(f'UserFirstName == "{user}"').reset_index()

    # filters out everything except pokemon name
    logan_pokemonbox = logan_pokemonbox[['Pokemon_Name']]


    # fixing typos
    if user == 'Logan':
        logan_pokemonbox['Pokemon_Name'] = [ name.replace('Victreebell', 'Victreebel')for name in logan_pokemonbox['Pokemon_Name'] ]
    if user == 'Matt':
         logan_pokemonbox['Pokemon_Name'] = [ name.replace('Toxtricity', 'Toxtricity-Low-Key')for name in logan_pokemonbox['Pokemon_Name'] ]
    if user == 'Colin':
         logan_pokemonbox['Pokemon_Name'] = [ name.replace('Morpeko', 'Morpeko-full-belly')for name in logan_pokemonbox['Pokemon_Name'] ]
         logan_pokemonbox['Pokemon_Name'] = [ name.replace('Enamorus', 'Enamorus-Therian')for name in logan_pokemonbox['Pokemon_Name'] ]

    # general url path to sprites
    image_gen = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/"

    # makes a column for each pokemon
    num_columns = len(logan_pokemonbox['Pokemon_Name'])
    cols = st.columns(num_columns)
    
    # for each columns display an image and name of the pokemon
    for i, col in enumerate(cols):
        with col:
            st.image(f'{image_gen}{pokedex.get(name=logan_pokemonbox["Pokemon_Name"].loc[i]).dex}.png',
                     caption=logan_pokemonbox["Pokemon_Name"].loc[i])

    # for each pokemon display a bigger image, and a dataframe of stats at new line for each one
    for pokemon in logan_pokemonbox['Pokemon_Name']:
        st.write('___________________________________________________________________________________')
        st.subheader(pokemon)
        col1, col2 = st.columns([0.5, 1])
        with col1:
            st.image(f'{image_gen}{pokedex.get(name=pokemon).dex}.png', caption=pokemon, width=400)
        with col2:
            st.subheader('')
            stat_dict = pokedex.get(name=pokemon).base_stats
    
            stats_cols = ['HP', 'Attack', 'Defense', 'Special Attack', 'Special Defense', 'Speed']
            stat_df = pd.DataFrame(columns=['Stats'], data=pokedex.get(name=pokemon).base_stats, index=stats_cols)
    
            st.dataframe(stat_df)
